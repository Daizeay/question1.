[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/YUSN3-AH)
# Weekly-Assignments


**Clone the Repository**

```bash
git clone <repository-url>
```

**Solve the Problem**
- Locate **CSC362 - Assignment XXXX.pdf** inside **Assignment-XXXX** folder in the cloned repository.
- Follow the instructions in the PDF and solve the problem.
- Save your solution as **question-XXXX.c**

**Upload the file**

```bash
git add question-XXXX.c
git commit -m "Completed Assignment XXXX - question-XXXX.c"
git push origin main
```
